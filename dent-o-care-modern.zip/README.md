# The Dent-O-Care — Modern Website

Premium light-theme dental clinic website built with Next.js, TypeScript, CSS and Framer Motion.

## Run

```bash
npm install
npm run dev
```

Open http://localhost:3000

## Build

```bash
npm run build
npm start
```

## Notes
- Clinic phone: +91 82497 75514
- Address: PLOT NO 133A, Forest Park Rd, Forest Park, Bhubaneswar, Odisha 751009
- WhatsApp and directions CTAs are wired to the provided business details.
- Clinical gallery uses the images supplied in the conversation.
- No doctor credentials, ratings, awards, fees or testimonials have been invented.
