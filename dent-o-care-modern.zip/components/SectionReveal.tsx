'use client';
import { motion } from 'framer-motion';
export function SectionReveal({children}:{children:React.ReactNode}){return <motion.div initial={{opacity:0,y:22}} whileInView={{opacity:1,y:0}} viewport={{once:true,margin:'-60px'}} transition={{duration:.55,ease:'easeOut'}}>{children}</motion.div>}
