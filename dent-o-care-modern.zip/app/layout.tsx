import './globals.css';
import { Navbar } from '@/components/Navbar';
import { Footer } from '@/components/Footer';
import { MessageCircle } from 'lucide-react';
import type { Metadata } from 'next';
export const metadata: Metadata = { title:'The Dent-O-Care | Dental Clinic in Bhubaneswar', description:'The Dent-O-Care dental clinic in Forest Park, Bhubaneswar, Odisha. Explore dental services, clinical case work and appointment contact options.' };
export default function RootLayout({children}:{children:React.ReactNode}){return <><Navbar/>{children}<a className="floating btn btn-primary" href="https://wa.me/918249775514?text=Hello%20The%20Dent-O-Care%2C%20I%20would%20like%20to%20book%20an%20appointment."><MessageCircle size={18}/> WhatsApp Clinic</a><Footer/></>}
